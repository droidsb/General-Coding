# Terminal Chat

This is a dead simple chat client and server run in the terminal and powered by Socket.io. It's easy to set up and great for Node developer teams.

To start a local server: `$ tchat start`
To connect to a local server `$ tchat connect -u thisisme`